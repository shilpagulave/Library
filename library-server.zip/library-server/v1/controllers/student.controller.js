// const Student = require("../models/student.model");
const bcrypt = require("bcrypt");
const { Student, validate } = require("../models/student.model"); // validate object pass from user
const _ = require("lodash");
const jwt = require("jsonwebtoken");

class StudentCtrl {
  // create(req, res) {
  //   let stud = new Student(req.body);
  //   stud.save((err, result) => {
  //     if (err) res.status(500).send(JSON.stringify(err));
  //     res.status(200).send(JSON.stringify(result));
  //   });
  // }
  // for password

  // display(req, res) {
  //   Student.find({}, (err, result) => {
  //     if (err) res.status(404).send(err);
  //     res.status(200).send(JSON.stringify(result));
  //   });
  // }

  create(req, res) {
    let s = req.body;

    const { error } = validate(s); // call validate function and pass data come from req body for validation
    if (error) res.status(500).send(JSON.stringify(error));
    else
      bcrypt.hash(s.pass, 10, function(err, hash) {
        if (err) res.status(500).send(JSON.stringify(err));
        s.pass = hash;
        let stud = new Student(s);
        stud.save((err, result) => {
          if (err) res.status(500).send(JSON.stringify(err));
          res.status(200).send(JSON.stringify(result));
        });
      });
  }

  // update(req, res) {
  //   res.send("student updated");
  // }
  // delete(req, res) {
  //   res.send("record deleted sucessfully");
  // }

  authonticate(req, res) {
    Student.findOne({ email: req.body.email }, (err, result) => {
      if (err | (result == null))
        res.status(404).send({ message: "Invalid email id" });
      else
        bcrypt.compare(req.body.pass, result.pass, function(err, res1) {
          if (err | (res1 == false))
            res.status(404).send({ message: "Invalid Password" });

          //token code
          jwt.sign(
            { admin: true, _id: result._id },
            "ab1234",
            { algorithm: "HS256" },
            function(err, token) {
              if (err) console.log(err);
              console.log(token);
              res.set("X-token", token);
              res
                .status(200)
                .send(JSON.stringify(_.pick(result, ["email", "pass"])));
            }
          );
        });
    });
  }
}
module.exports = StudentCtrl;
