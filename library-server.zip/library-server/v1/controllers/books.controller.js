const { Books, validate } = require("../models/books.model");
// const bcrypt = require("bcrypt");

const _ = require("lodash");
class BooksCtrl {
  display(req, res) {
    Books.find({}, (err, result) => {
      if (err) res.status(404).send(err);
      res.status(200).send(JSON.stringify(result));
    });
  }

  create(req, res) {
    let s = req.body;
    // console.log(s);
    const { error } = validate(s);
    if (error) res.status(500).send(JSON.stringify(error));

    let bk = new Books(s);
    bk.save((err, result) => {
      if (err) res.status(500).send(JSON.stringify(err));
      res.status(200).send(JSON.stringify(result));
    });
  }

  // update(req, res) {
  //   res.send("Books updated");
  // }
  deleterecord(req, res) {
    // console.log(s);
    console.log(req.params.id);
    let a = req.params.id;

    Books.deleteOne({ _id: a }, (err, result) => {
      if (err) res.status(500).send(JSON.stringify(err));
      res.status(200).send(JSON.stringify(result));
    });
  }
}
module.exports = BooksCtrl;
