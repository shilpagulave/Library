const bcrypt = require("bcrypt");
const { Librarian, validate } = require("../models/librarian.model");
// const bcrypt = require("bcrypt");
const _ = require("lodash");
const jwt = require("jsonwebtoken");
class LibrarianCtrl {
  // create(req, res) {
  //   let stud = new Student(req.body);
  //   stud.save((err, result) => {
  //     if (err) res.status(500).send(JSON.stringify(err));
  //     res.status(200).send(JSON.stringify(result));
  //   });
  // }
  // for password

  // display(req, res) {
  //   Librarian.find({}, (err, result) => {
  //     if (err) res.status(404).send(err);
  //     res.status(200).send(JSON.stringify(result));
  //   });
  // }

  // update(req, res) {
  //   res.send("Librarian updated");
  // }
  // delete(req, res) {
  //   res.send("Librarian record deleted sucessfully");
  // }

  // authonticate(req, res) {
  //   Librarian.findOne({ email: req.body.email }, (err, result) => {
  //     if (err | (result == null))
  //       res.status(404).send({ message: "Invalid email id" });
  //     else
  //       bcrypt.compare(req.body.pass, result.pass, function(err, res1) {
  //         if (err | (res1 == false)) {
  //           res.status(404).send({ message: "Invalid Password" });
  //         } else res.status(200).send(JSON.stringify(_.pick(result, ["name", "mobile", "email"])));
  //       });
  //   });
  // }

  create(req, res) {
    let s = req.body;

    const { error } = validate(s); // call validate function and pass data come from req body for validation
    if (error) res.status(500).send(JSON.stringify(error));
    else
      bcrypt.hash(s.pass, 10, function(err, hash) {
        if (err) res.status(500).send(JSON.stringify(err));
        s.pass = hash;
        let lab = new Librarian(s);
        lab.save((err, result) => {
          if (err) res.status(500).send(JSON.stringify(err));
          res.status(200).send(JSON.stringify(result));
        });
      });
  }

  authonticate(req, res) {
    Librarian.findOne({ email: req.body.email }, (err, result) => {
      if (err | (result == null))
        res.status(404).send({ message: "Invalid email id" });
      else
        bcrypt.compare(req.body.pass, result.pass, function(err, res1) {
          if (err | (res1 == false))
            res.status(404).send({ message: "Invalid Password" });

          //token code
          jwt.sign(
            { admin: true, _id: result._id },
            "ab1234",
            { algorithm: "HS256" },
            function(err, token) {
              if (err) console.log(err);
              console.log(token);
              res.set("X-token", token);
              res
                .status(200)
                .send(JSON.stringify(_.pick(result, ["email", "pass"])));
            }
          );
        });
    });
  }
}
module.exports = LibrarianCtrl;
