const mongoose = require("mongoose");
const Joi = require("@hapi/joi");
mongoose.connect("mongodb://localhost:27017/topper");
mongoose.connection;
const Schema = mongoose.Schema;

const StudentSchema = new Schema({
  name: { type: String, required: true },
  mobile: String,
  pass: String,
  email: String
});

const Student = mongoose.model("Stu", StudentSchema);

function validate(studentObj) {
  const schema = Joi.object()
    .keys({
      name: Joi.string()
        .alphanum()
        .min(3)
        .max(30)
        .required(),
      mobile: [Joi.string(), Joi.number()],
      pass: Joi.string().regex(/^[a-zA-Z0-9]{3,30}$/),

      email: Joi.string().email({ minDomainSegments: 2 })
    })
    .with("name", "email");
  return Joi.validate(studentObj, schema);
}

module.exports = { Student, validate };
