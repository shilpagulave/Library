const mongoose = require("mongoose");
const Joi = require("@hapi/joi");
mongoose.connect("mongodb://localhost:27017/topper");
mongoose.connection;
const Schema = mongoose.Schema;

const BooksSchema = new Schema({
  id: { type: String },
  name: { type: String, required: true },
  author: { type: String, required: true },
  publication: { type: String, required: true },
  price: Number
});
function validate(bookObj) {
  const schema = Joi.object()
    .keys({
      id: Joi.string(),
      name: Joi.string()
        .min(3)
        .max(30)
        .required(),
      author: Joi.string()
        .min(3)
        .max(30)
        .required(),
      publication: Joi.string()
        .min(3)
        .max(30)
        .required(),
      price: [Joi.string(), Joi.number()]
    })
    .with("name", "author");
  return Joi.validate(bookObj, schema);
}
const Books = mongoose.model("book", BooksSchema);
module.exports = { Books, validate };
