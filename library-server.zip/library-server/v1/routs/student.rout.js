const express = require("express");
const router = express.Router();
const StudentCtrl = require("../controllers/student.controller");

const studObj = new StudentCtrl();

router.post("/login", studObj.authonticate);
// router.get("/display", studObj.display);
router.post("/create", studObj.create);

// router.put("/update/:id", studObj.update);

// router.delete("/delete/:id", studObj.delete);
// router.post("/authonticate", studObj.authonticate);

module.exports = router;

// (req, res) => {
//   res.send("updated by v1");
// }
