const express = require("express");
const router = express.Router();
const BooksCtrl = require("../controllers/books.controller");
const bookObj = new BooksCtrl();

// router.get("/", (req, res) => {
//   res.send("hello librarian");
// });

router.get("/display", bookObj.display);

router.post("/create", bookObj.create);

// router.put("/update/:id", bookObj.update);

router.delete("/delete/:id", bookObj.deleterecord);
// router.post("/authonticate", bookObj.authonticate);

module.exports = router;

// (req, res) => {
//   res.send("updated by v1");
// }
