const express = require("express");
const router = express.Router();
const LibrarianCtrl = require("../controllers/librarian.controller");
const libObj = new LibrarianCtrl();

// router.get("/", (req, res) => {
//   res.send("hello librarian");
// });

// router.get("/dispslay", libObj.display);

router.post("/create", libObj.create);

// router.put("/update/:id", libObj.update);

// router.delete("/delete/:id", libObj.delete);
router.post("/login", libObj.authonticate);

module.exports = router;

// (req, res) => {
//   res.send("updated by v1");
// }
