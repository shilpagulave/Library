const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  res.send("hello");
});

router.post("/create", (req, res) => {
  res.send("created by v2");
});

router.put("/update/:id", (req, res) => {
  res.send("updated by v2");
});

module.exports = router;
