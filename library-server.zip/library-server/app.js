const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const studentRoutes = require("./v1/routs/student.rout");
// const studentRoutesv2 = require("./v2/routs/student.rout");
const librarianRoutes = require("./v1/routs/librarian.rout");
const booksRoutes = require("./v1/routs/books.rout");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin,X-Requested-with,Content-Type,Authorization,Accept"
  );
  res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
  res.header("Access-Control-Expose-Headers", "X-token");

  next();
});

app.use("/api/v1/student", studentRoutes);

// app.use("/api/v2/student", studentRoutesv2);
app.use("/api/v1/librarian", librarianRoutes);
app.use("/api/v1/books", booksRoutes);

let port = "7777";
app.listen(port, () => {
  console.log("server start on port no" + port);
});
